#ifndef _UTILS_H_
#define _UTILS_H_

/* Function prototypes */
void create_default_directories(void);
char* get_save_directory(void);
char* gcw0_get_key_name(int keycode);
char *get_file_name(char *full_path);
#endif /* _UTILS_H_ */

