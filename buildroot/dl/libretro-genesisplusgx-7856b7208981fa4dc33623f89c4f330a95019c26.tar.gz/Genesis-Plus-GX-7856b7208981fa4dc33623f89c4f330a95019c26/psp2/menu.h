#ifndef _MENU_H
#define _MENU_H

void InitMenu();
void DisplayMenu();
void TrashMenu();

#endif
