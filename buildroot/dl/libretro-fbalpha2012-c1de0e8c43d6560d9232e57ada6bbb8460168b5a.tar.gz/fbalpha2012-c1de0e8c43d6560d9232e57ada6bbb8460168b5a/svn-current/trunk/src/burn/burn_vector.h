#ifndef _BURN_VECTOR_H
#define _BURN_VECTOR_H

void draw_vector(UINT32 *palette);
void vector_init();
void vector_reset();
INT32 vector_scan(INT32 nAction);
void vector_exit();
void vector_add_point(INT32 x, INT32 y, INT32 color, INT32 intensity);

#endif
