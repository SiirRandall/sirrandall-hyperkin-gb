/* v3021 Calendar Emulation */

UINT8 v3021Read();
void v3021Write(UINT16 data);

INT32 v3021Scan();
